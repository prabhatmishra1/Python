''' We have used pymupdf module for the pdf munpulation, you can install it using
    this link https://pymupdf.readthedocs.io/en/latest/installation.html
'''
import fitz
import pathlib
import os

# Get current file path
current_path = pathlib.Path(__file__).parent.absolute()

# Create input and output folders if doesn't exist
input_folder = os.path.join(current_path, 'input')
output_folder = os.path.join(current_path, 'output')
if not os.path.exists(input_folder):
    os.makedirs(input_folder)
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

REPLACEMENT_DICT = {
    '{FULL NAME}': 'JOHN TURNE',
    '{number1}': '123456',
    '{number2}': 'AA123456',
    '{date11111}': '17/12/2021'
}

# DEFINE COLORS
white = (1, 1, 1)
blue = (0, 0,.6)

def process_pdf(doc, image_filename=None):
    output_filename = 'result.pdf'
    output_file_path = os.path.join(current_path, 'output', output_filename)
    replace_image_path = os.path.join(current_path, 'assets', 'QR.jpg')
    # now read the page
    page = doc.loadPage(0)

    #TEXT REPLACEMENT
    for rep_key, rep_value in REPLACEMENT_DICT.items():
        text_instances = page.searchFor(rep_key)
        for inst in text_instances:
                    text_point = fitz.Point(inst[0], inst[3])
                    # Creating a white strip
                    shape = page.newShape()  # create Shape
                    shape.draw_rect(inst)
                    shape.finish(color = white, fill = white)
                    # Intsert the replacement TEXT over the strip
                    shape.insertText(text_point, rep_value, color = blue)
                    shape.commit()

    # Check for Image
    if image_filename:
        # Insert Image:
        replace_image_path = os.path.join(current_path, 'assets', image_filename)
        # Get the rect dynamically here
        img_list = doc.getPageImageList(0, full=True)  # important: use 'full' parameter
        item = img_list[0] #fetch first image rect in the page
        img_rect = page.getImageBbox(item)
        shape = page.newShape()  # create Shape
        shape.draw_rect(img_rect)
        shape.finish(color = white, fill = white)
        shape.commit()
        page.insertImage(img_rect, filename=replace_image_path)

    # save final doc here
    doc.save(output_file_path, garbage=4, deflate=True, clean=True)

if __name__ == "__main__":
    # Get the pdf file
    #define your input path here
    # filename = 'TEST PDF INPUT TEMPLATE.pdf'
    input_filename = input('\nInput the PDF file name: ')
    ask_for_image = input('\n Do you want to replace the image ? \n Enter yes or no: ')
    if (ask_for_image == 'yes'):
        image_filename = input('\nInput the Image file name: ')
    else:
        image_filename = None

    input_file = os.path.join(current_path, 'input', input_filename)

    doc = fitz.open(input_file)  # open document
    process_pdf(doc, image_filename = image_filename)
